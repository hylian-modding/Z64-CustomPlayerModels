"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const CoreInjection_1 = require("modloader64_api/CoreInjection");
const path_1 = __importDefault(require("path"));
const fs_extra_1 = __importDefault(require("fs-extra"));
const EventHandler_1 = require("modloader64_api/EventHandler");
const OotoAPI_1 = require("./OotoAPI/OotoAPI");
const zlib_1 = __importDefault(require("zlib"));
class KrysVox {
    constructor() {
        this.sounds = new Map();
        this.rawSounds = {};
        /*
        LUI A0, 0x8060
        SH A1, 0x0088(A0)
        */
        this.nop = Buffer.from('3C048060A4850088', 'hex');
    }
    getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    preinit() {
        let sound_folder = path_1.default.resolve(__dirname, "sounds");
        fs_extra_1.default.readdirSync(sound_folder).forEach((file) => {
            let f = path_1.default.resolve(sound_folder, file);
            let id = parseInt(path_1.default.parse(file).name.split("-")[0].trim(), 16);
            if (fs_extra_1.default.lstatSync(f).isDirectory()) {
                this.sounds.set(id, []);
                this.rawSounds[id] = [];
                fs_extra_1.default.readdirSync(f).forEach((sound) => {
                    let s = path_1.default.resolve(f, sound);
                    this.ModLoader.logger.info("Loading " + path_1.default.parse(s).base + ".");
                    let snd = this.ModLoader.sound.loadSound(s);
                    this.sounds.get(id).push(snd);
                    this.rawSounds[id].push(zlib_1.default.deflateSync(fs_extra_1.default.readFileSync(s)));
                });
            }
        });
    }
    init() {
    }
    postinit() {
        EventHandler_1.bus.emit(OotoAPI_1.OotOnlineEvents.ON_LOAD_SOUND_PACK, this.rawSounds);
    }
    onTick(frame) {
        let dir = this.core.global.viewStruct.position.minus(this.core.global.viewStruct.focus).normalized();
        this.ModLoader.sound.listener.position = this.core.global.viewStruct.position;
        this.ModLoader.sound.listener.direction = dir;
        this.ModLoader.sound.listener.upVector = this.core.global.viewStruct.axis;
        if (!this.core.helper.isPaused()) {
            this.ModLoader.emulator.rdramWriteBuffer(0x80389048, this.nop);
        }
        if (this.core.link.current_sound_id > 0) {
            if (this.sounds.has(this.core.link.current_sound_id)) {
                let random = this.getRandomInt(0, this.sounds.get(this.core.link.current_sound_id).length - 1);
                let sound = this.sounds.get(this.core.link.current_sound_id)[random];
                sound.position = this.core.link.position;
                sound.minDistance = 250.0;
                sound.play();
            }
            else {
                //this.ModLoader.logger.error("Missing sound id " + this.core.link.current_sound_id.toString(16));
            }
        }
        this.sounds.forEach((sound, key) => {
            for (let i = 0; i < sound.length; i++) {
                sound[i].position = this.core.link.position;
            }
        });
    }
}
__decorate([
    CoreInjection_1.InjectCore()
], KrysVox.prototype, "core", void 0);
module.exports = KrysVox;
//# sourceMappingURL=KrysVox.js.map